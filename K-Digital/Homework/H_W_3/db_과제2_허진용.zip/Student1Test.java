import java.util.ArrayList;

import DAO.Student1DAO;
import DTO.Student1DTO;


public class Student1Test {
	public static void printAllStudents() {
		Student1DAO dao1 = new Student1DAO();
		ArrayList<Student1DTO> mlist = dao1.printAllStudents();
		for (Student1DTO m : mlist) {
			System.out.println(m);
		}
	}
	
	public static void insertStudent() {
		Student1DAO dao = new Student1DAO();
		int rcnt = dao.insertStudent1(new Student1DTO(3,"나길동","영문학과","제주","010-3333-3333"));
		if(rcnt>0) {
			System.out.println("삽입 성공");
		} else {
			System.out.println("삽입 실패");
		}
	}
	
	public static void main(String[] args) {
//		insertStudent();
		printAllStudents();
	}
		
//	public static void main(String[] args) {
////		StudentDAO dao = new StudentDAO();
////		int rcnt = dao.insertStudent(new StudentDTO(3,"나길동","영문학과","제주","010-3333-3333"));
////		if(rcnt>0) {
////			System.out.println("삽입 성공");
////		} else {
////			System.out.println("삽입 실패");
////		}
//		
//		StudentDAO dao1 = new StudentDAO();
//		ArrayList<StudentDTO> mlist = dao1.printAllStudents();
//		for (StudentDTO m : mlist) {
//			System.out.println(m);
//		}
//		
//	public static void main(String[] args) {
//
//	}
}
