package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import DTO.Student1DTO;

public class Student1DAO {
	Connection conn;

	public Student1DAO() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public ArrayList<Student1DTO> printAllStudents() {
		Statement stmt = null;
		ResultSet rset = null;
		String sql = "select * from student1";
		ArrayList<Student1DTO> list = new ArrayList<>();
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(sql);
			while (rset.next()) {
				Student1DTO mem = new Student1DTO();
				mem.setNo(rset.getInt("no"));
				mem.setName(rset.getString("name"));
				mem.setDet(rset.getString("det"));
				mem.setAddr(rset.getString("addr"));
				mem.setTel(rset.getString("tel"));
				list.add(mem);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rset != null)
					rset.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public int insertStudent1(Student1DTO student1dto) {
		String sql = "insert into student1 values(?,?,?,?,?)";
		PreparedStatement pstmt = null;
		int rcnt = 0;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, student1dto.getNo());
			pstmt.setString(2, student1dto.getName());
			pstmt.setString(3, student1dto.getDet());
			pstmt.setString(4, student1dto.getAddr());
			pstmt.setString(5, student1dto.getTel());
			rcnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rcnt;
	}

}
